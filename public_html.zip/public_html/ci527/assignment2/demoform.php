<html>
<body>
<?php echo $html; ?>
<form action="api.php" method="post">
To: <input type="text" name="to"><br>
From: <input type="text" name="from"><br>
Message: <input type="text" name="message"><br>
<input type="submit">
</form>

</body>
</html>