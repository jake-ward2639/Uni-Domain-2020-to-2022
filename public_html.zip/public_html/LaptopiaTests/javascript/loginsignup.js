window.addEventListener('load', function(evt){
    
    var signupBtn = document.querySelector('#signup-btn'),
    loginBtn = document.querySelector('#login-btn'),
    loginUsername = document.querySelector('#login-username');
    loginPassword = document.querySelector('#login-password');
    
    signupBtn.addEventListener('click', function(evt){
        evt.preventDefault();
    })
    
    loginBtn.addEventListener('click', function(evt){
        evt.preventDefault();
        window.location.href = 'https://jw1448.brighton.domains/LaptopiaTests/html/loginsignup.php?lusername=' + loginUsername.value.trim() + '&lpassword=' +  loginPassword.value.trim();
    })
    
})