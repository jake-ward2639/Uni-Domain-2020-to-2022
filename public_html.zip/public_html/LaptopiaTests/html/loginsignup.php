<?php
    
	$html = '';
	
	if(isset($_GET['lusername'])&&isset($_GET['lpassword'])){
    	$lUsername = $_GET['lusername'];
    	$lPassword = $_GET['lpassword'];
    	
    	$conn = mysqli_connect('localhost', 'cw1019_admin', '0B+F4pp_~u{p', 'cw1019_laptopia_database');
    	
    	if (!$conn) {
          $html = "Connection failed: " . $conn->connect_error;
        } else {
            $lUsername = $conn->real_escape_string($lUsername);
            $lPassword = $conn->real_escape_string($lPassword);
            
            $sql = "SELECT * FROM Users WHERE Username = '$lUsername' AND Password = '$lPassword'";
            
            $result = $conn->query($sql);
    
            if ($result->num_rows > 0) {
              while($row = $result->fetch_assoc()) {
                $html = " Username: " . $row["Username"] . " Logged in";
              }
            } else {
              $html = "0 results";
            }
            $conn->close();
        }
	}
	
	if(isset($_GET['susername'])&&isset($_GET['spassword'])&&isset($_GET['email'])){
    	$sUsername = $_GET['susername'];
    	$sPassword = $_GET['spassword'];
    	$email = $_GET['email'];
	}
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <script src="../javascript/loginsignup.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <script src="https://kit.fontawesome.com/b94f75224e.js" crossorigin="anonymous"></script> 
    <link rel="stylesheet" href="../css/loginsignup.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laptopia | Login & Sign up</title>
</head>
<body>
    
    <div class="container">
        <div class="switch">
            <div class="login" onclick="tab1();">Login</div>
            <div class="signup" onclick="tab2();">Sign Up</div>
        </div>

        <div class="outer">
            <form id="form">
                <div id="pg1" class="page">
                    <h3>Login to Laptopia <?php echo $sql . $html ?></h3>
                    <div class="element">
                        <input id="login-username" type="text" placeholder="Username">
                        <span class="fas fa-user"></span>
                    </div>
                    <div class="element">
                        <input id="login-password" type="password" placeholder="Password">
                        <span class="fas fa-lock"></span>
                        <span class="far fa-eye-slash" onclick="togglePassword1(this)"></span>
                    </div>
                    <button id="login-btn" class="btn">Login</button>
                </div>

                <div id="pg2" class="page">
                    <h3>Sign up to Laptopia</h3>
                    <div class="element">
                        <input id="email" type="email" placeholder="Enter Email Address" autocomplete="off">
                        <span class="fas fa-envelope"></span>
                        <span id="email-msg"></span>
                    </div>
                    <div class="element">
                        <input id="signup-username" type="text" placeholder="Create Username">
                        <span class="fas fa-user"></span>
                    </div>
                    <div class="element">
                        <input id="signup-password" type="password" placeholder="Create Password">
                        <span class="fas fa-lock"></span>
                        <span class="far fa-eye-slash" onclick="togglePassword2(this)"></span>
                    </div>
                    <button id="signup-btn" class="btn">Sign up</button>
                </div>
            </form>
        </div>
    </div>
    <script src="../javascript/index.js"></script>
    <script src="../javascript/validation.js"></script>
</body>
</html>