window.addEventListener('load', function(evt){
    var search = document.querySelector('#searchCriteria'), //create variables for the different pages available
        contact = document.querySelector('#contact'),
        loading = document.querySelector('#loading'),
        searchResults = document.querySelector('#searchResults'),
        errorMessages = document.querySelectorAll('.errors');

        function clearErrors(){
            for (let i = 0; i < errorMessages.length;i++){ //remove all error messages
                errorMessages[i].style.display = 'none';
            }
        }

    search.addEventListener('submit', function(evt){ //upon submit clicked
        evt.preventDefault()
        if(!navigator.onLine){
            errorMessageInternet = document.querySelector('#errorMessageInternet'); //check if connection is online
            clearErrors();
            errorMessageInternet.style.display = 'block';
        } else {

            var uri = document.querySelector('#searchTerm').value.trim(), //get the searchterm, check if anything was input, throw error if not
                errorMessage0 = document.querySelector('#errorMessage0');
            if (uri.length === 0){ errorMessage0.style.display = 'inline-block'; }
            else {

                var encoded = encodeURIComponent(uri), //encode searchterm, get link to contact the api, other errors, request and previous results
                    searchLink = 'https://images-api.nasa.gov/search?q='+encoded+'&media_type=image',
                    errorMessageResult = document.querySelector('#errorMessageResult'),
                    xhr = new XMLHttpRequest(),
                    deletableResults = document.querySelectorAll('.searchResult');

                for (let i = 0; i < deletableResults.length;i++){ //delete previous results
                    deletableResults[i].remove();
                }
                contact.style.display = 'none'; //show loading until the results have loaded
                loading.style.display = 'block';

                xhr.addEventListener('load', function(){ //upon loading
                    if (xhr.status == 200) {

                    var txt = xhr.responseText, //get response text, parse and get totalhits
                        obj = JSON.parse(txt),
                        totalHits = obj.collection.metadata.total_hits;

                        if (totalHits === 0){
                            errorMessageResult.style.display = 'block';
                            loading.style.display = 'none'; //remove load and restore form
                            contact.style.display = 'block';
                        } else{

                            obj.collection.items.forEach(function(item){ //for every item retrived

                            var title = item.data[0].title, //get the title, link, description and date
                                link = item.links[0].href,
                                date = item.data[0].date_created,
                                desc = item.data[0].description;

                            var titleGot = document.createElement("h3"); //create the images, titles and etc from retrived info
                            titleGot.setAttribute("class", "searchResult");
                            titleGot.textContent = title;
                            searchResults.appendChild(titleGot);

                            var dateGot = document.createElement("p");
                            dateGot.setAttribute("class", "searchResult");
                            dateGot.textContent = date;
                            searchResults.appendChild(dateGot);

                            var imageGot = document.createElement("IMG"); 
                            imageGot.setAttribute("class", "searchResult");
                            imageGot.setAttribute("alt", title);
                            imageGot.setAttribute("src", link);
                            searchResults.appendChild(imageGot);

                            var descGot = document.createElement("p");
                            descGot.setAttribute("class", "searchResult");
                            descGot.textContent = desc;
                            searchResults.appendChild(descGot);
                            })

                            loading.style.display = 'none'; //remove load and restore form
                            contact.style.display = 'block';
                        }
                    } else { //if the connection wasnt successful then throw error
                        clearErrors();
                        var errorMessageServer = document.querySelector('#errorMessageServer');
                        errorMessageServer.style.display = 'block';
                    }
                })
                xhr.open("GET", searchLink, true); //setup xhr and send asyncronously
                xhr.send(encoded);
                clearErrors();
            }
        }
    })
});
