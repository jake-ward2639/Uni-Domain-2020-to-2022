<?php
    $html = '';
    if(isset($_POST[user])&&isset($_POST[fName])&&isset($_POST[lName])){
        $username = $_POST[user];
        $firstname = $_POST[fName];
        $lastname = $_POST[lName];
        
        $mysqli = new mysqli('localhost', 'jw1448_jakeward2639', 'sXC+n%L&SN^7', 'jw1448_ci527_database');
        if($mysqli->connect_error == null){
        	
        	$username = $mysqli->real_escape_string($username);
        	$firstname = $mysqli->real_escape_string($firstname);
        	$lastname = $mysqli->real_escape_string($lastname);
        	
        	$sql = "INSERT INTO TestUsers (Username, FName, LName)"
        	     . "VALUES ('$username','$firstname','$lastname')";
        	     
        	$success = $mysqli->query($sql);
        	if($success){
        		$id = $mysqli->insert_id;
        		$html = 'Thanks, created record with id $id';
        	}else{
        		$html = "Couldnt Execute $sql";
        	}
        	
        }else{
        	$html = 'Not Connected to Database';
        }
    }
?>
<html>
<body>
<?php echo $html; ?>
<form action="sqlTest.php" method="post">
Username: <input type="text" name="user"><br>
First Name: <input type="text" name="fName"><br>
Last Name: <input type="text" name="lName"><br>
<input type="submit">
</form>

</body>
</html>