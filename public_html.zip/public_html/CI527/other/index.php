<?php
 // define classes
 // use classes to convert values
 // store results in $var1, $var2, ...
 
 abstract class Convert {
     abstract public function convert($parameter1);
 }
 
 class C2FConverter extends Convert {
     public function convert($parameter1) {
        return (float)(($parameter1 * 9 / 5) + 32);
     }
}

 class F2CConverter extends Convert {
     public function convert($parameter1) {
        return (float)($parameter1 - 32) * (5/9);
     }
}
 class EUR2GBPConverter extends Convert {
     public function convert($parameter1) {
        return (float)(($c * 9 / 5) + 32);
     }
}
$var1 = C2FConverter::convert(27);
$var2 = F2CConverter::convert(27);
?>
<!DOCTYPE html>
<html>
 <head>
 <meta charset="utf-8">
 <title>PHP introduction (3)</title>
 </head>
 <body>
 <p>27 &deg; C = <?php echo $var1?> &deg; F</p>
 <p>27 &deg; F = <?php echo $var2 ?> &deg; C</p>
 <p>999 EUR = <?php /* write result */ ?> GBP</p>
 <p>(exchange rate = <?php /* write result */ ?>,
 flat fee = <?php /* write result */ ?> GBP) </p>
 </body>
</html>