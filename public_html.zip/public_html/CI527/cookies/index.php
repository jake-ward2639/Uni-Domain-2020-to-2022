<?php
    
    $username = null;
    $html = '';
    $link = '';

    if($_GET['logout']) {

        // logout...
        setcookie('username', '', time() - 60*60, "/CI527/cookies/", "http://jw1448.brighton.domains/");

    } else {
        if (isset($_COOKIE['username'])){

            // user was logged in already
            $username = $_COOKIE['username'];
            $link .= ' | <a href="index.php?logout=1">Logout</a>';
     
        } else  if (isset($_POST['username']) && isset($_POST['password'])){
    
            // user is logging in right now
            $username = $_POST['username'];
            setcookie('username', $username, time()+ 60*60, "/CI527/cookies/", "http://jw1448.brighton.domains/");
            $logged_in = true;
    
        } // else user is not logged in: show form    
    }
    

    if($username) {

        // show welcome
        $html .= 'Welcome back, ' . $username;
    } else {

        // show form
        $html .= '<form action="'. $_SERVER['PHP_SELF'] .'" method="POST">'
               . '<label for="username">Username:</label><input id="username" name="username" type="text" />'
               . '<label for="password">Password:</label><input id="password" name="password" type="password" />'
               . '<input type="submit" name="login" value="Login" />'
               . '</form>';
    }

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="index.css" /> 
    <title>Cookie Tutorial Page 1</title>
</head>

<body>

    <h1>Cookie Tutorial Page 1</h1>

    <?php echo $html; ?>

    <hr>
    <a href="index2.php">Page 2</a> |      
    <a href="index3.php">Page 3</a>  
    <?php echo $link; ?>    

</body>

</html>