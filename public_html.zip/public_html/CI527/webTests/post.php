<html>
<body>

<form action="get.php" method="post">
param1: <input type="text" name="param1"><br>
param2: <input type="text" name="param2"><br>
<input type="submit">
</form>

</body>
</html>