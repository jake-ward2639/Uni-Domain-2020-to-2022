<!DOCTYPE html>
<html>
 <head>
 <meta charset="utf-8">
 <title>Requests</title>
 </head>
 <body>
 <p>Element1 <?php echo $_POST["param1"]; ?></p>
 <p>Element 2 <?php echo $_POST["param2"]; ?></p>
 </body>
</html>